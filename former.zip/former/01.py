
from selenium import webdriver
options = webdriver.ChromeOptions()
options.add_argument('--user-data-dir=user')
driver = webdriver.Chrome("C:\chromedriver.exe",chrome_options=options) 
driver.get("https://www.google.com/")
