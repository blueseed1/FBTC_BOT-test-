
from selenium import webdriver
import time
import getpass # 実行ユーザーを取得するために使用
import requests
import json
from selenium.webdriver.support.ui import Select
import datetime
import pytz
import csv

btc=0
pr=0

def main1(local):
    global btc
    global pr
    
    options = webdriver.ChromeOptions()
    options.add_argument('--user-data-dir=' + local)
    driver= webdriver.Chrome("C:\chromedriver.exe",options=options)

    driver.set_page_load_timeout(10)
    
    try:
        #指定したURLに遷移する
        driver.get("https://google.com")
        driver.get("https://freebitco.in/?op=home")
        driver.refresh()
        
        #10秒以内にページが完全にロードされた場合は以下を出力
        print("The page was loaded in time！")
    
    except:
        #ページが完全にロードされるまで10秒以上かかる場合は以下を出力
        print("erro")
        driver.quit()
    time.sleep(1)

    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
      
    def capt():
        # JSでtextareaタグのdisplay:noneを削除す
        driver.execute_script('var element=document.getElementById("g-recaptcha-response"); element.style.display="";')
        service_key = '0c0e09e70b1328c53531f9ec38283e45' # 2captcha service key 
        google_site_key = '6LeGfGIUAAAAAEyUovGUehv82L-IdNRusaYFEm5b' # reCAPTCHAのdata-sitekey
    
        pageurl = 'https://freebitco.in/?op=home' 
        url = "http://2captcha.com/in.php?key=" + service_key + "&method=userrecaptcha&googlekey=" + google_site_key + "&pageurl=" + pageurl 
    
        global resp
        resp = requests.get(url) 
        if resp.text[0:2] != 'OK': 
            quit('Service error. Error code:' + resp.text)
        
        global captcha_id
        captcha_id = resp.text[3:]
    
        print('キャプチャid:')
        print(captcha_id)
    
        fetch_url = "http://2captcha.com/res.php?key="+ service_key + "&action=get&id=" + captcha_id
 
        for i in range(1, 60):
            time.sleep(5) # wait 5 sec.
            resp = requests.get(fetch_url)
            if resp.text[0:2] == 'OK':
                break
        print('Google response token: ', resp.text[3:])
    
        # textareaにトークンを入力する
        driver.find_element_by_id('g-recaptcha-response').send_keys(resp.text[3:])
        driver.execute_script('var element=document.getElementById("g-recaptcha-response"); element.style.display="none";')
    
    def roll():
        try:
            cc=driver.find_element_by_link_text("Got it!")
            cc.click()
        except:
            print("cc無し")
        
        try:
            roll=driver.find_element_by_css_selector("#free_play_form_button")
            roll.click()
            print(local+" : ロール完了")
        except:
            print("エラー")
           
    er=0
    while er < 1:
        try:
            saku=driver.find_element_by_tag_name("h1")
            print(saku.text)
            er=er+1
        except:
            print("接続エラー")
    
    f=0
    try:
        time.sleep(1)
        cap=driver.find_element_by_id("play_without_captchas_button")
        cap.click()
        
        print("キャプチャ外し完了")
        time.sleep(1)
        
        kai=driver.find_element_by_css_selector(".play_without_captcha_description > p:nth-child(2)")
        print(kai.text)
        time.sleep(1)
      
        if "1" in kai.text:
            print("pr-1")
            f=1
            
        else:
            print("pr-2")
            caps=driver.find_element_by_id("play_with_captcha_button")
            time.sleep(1)
            caps.click()
            f=2
            time.sleep(1)
    except:
        try:
            roll()
        except:
            print(local+" : まだ時間じゃない")
            btc=0
            pr=0
        
    if f==1:
        try:
            roll()
            time.sleep(2)
        except:
            print("ロールクリックエラー")
        
        try:
            btcp=driver.find_element_by_id("winnings")
            btc=btcp.text
            print(str(btc)+" btc")
            prp=driver.find_element_by_id("fp_reward_points_won")
            pr=prp.text
            print(str(pr)+" PR")
        except:
            print("集計エラー")
            
        driver.refresh()
        
        print("結果確認")
        try:
            driver.find_element_by_id("play_without_captchas_button")
            print("エラー")
        except:
            print(local+" : ロールok")
            
    if f==2:
        print("2capへ")
        capt()
        roll()
        time.sleep(5)
        
        try:
            btcp=driver.find_element_by_id("winnings")
            btc=btcp.text
            print(str(btc)+" btc")
            
            prp=driver.find_element_by_id("fp_reward_points_won")
            pr=prp.text
            print(str(pr)+" PR")
        except:
            print("集計エラー")
        driver.refresh()
        print("2cap:結果確認")
        try:
            driver.find_element_by_id("play_without_captchas_button")
            print("エラー")
            url = "http://2captcha.com/res.php?key=2captchaのAPIキー&action=reportbad&id="+str(captcha_id)+"&json=1"
            e2c = requests.get(url)
            print (e2c.text)
            print("もう一回")
            time.sleep(5)
            
            aa=0
            while aa < 2:
                capt()
                roll()
                time.sleep(5)
                try:
                    btcp=driver.find_element_by_id("winnings")
                    btc=btcp.text
                    print(str(btc)+" btc")
                    prp=driver.find_element_by_id("fp_reward_points_won")
                    pr=prp.text
                    print(str(pr)+" PR")
                except:
                    print("集計エラー")
                
                driver.refresh()
                print("2cap:結果確認")
                
                try:
                    driver.find_element_by_id("play_without_captchas_button")
                    print("エラー")
                    url = "http://2captcha.com/res.php?key=2captchaのAPIキー&action=reportbad&id="+str(captcha_id)+"&json=1"
                    print(url)
                    e2c = requests.get(url)
                    print (e2c.text)
                    aa=aa+1
                    
                except:
                    print(local+" : 2cap:ok")
                    aa=aa+3
        except:
            print(local+" : 2cap:ok")
            
    time.sleep(3)
    driver.quit()
     
#すたーと
shu=0
user="user"
user2="user2"

#12回繰り返す場合
shu=0
while shu < 12:
    if shu > 0:
        print("3570秒待機")
        time.sleep(3570)
    main1(user)
    main1(user2)

    now = datetime.datetime.now(pytz.timezone('Asia/Tokyo'))
    print(now)
    shu=shu+1

print("指定回数終了")
